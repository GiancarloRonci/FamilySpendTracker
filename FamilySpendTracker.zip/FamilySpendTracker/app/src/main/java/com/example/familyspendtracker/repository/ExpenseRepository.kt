package com.example.familyspendtracker.repository

import com.example.familyspendtracker.data.*
import kotlinx.coroutines.flow.Flow

class ExpenseRepository(
    private val categoryDao: CategoryDao,
    private val expenseDao: ExpenseDao,
    private val walletDao: WalletDao // ➕ aggiunto
) {
    // Categorie
    val categories: Flow<List<Category>> = categoryDao.getAll()
    suspend fun addCategory(category: Category) = categoryDao.insert(category)

    // Wallets
    val wallets: Flow<List<Wallet>> = walletDao.getAll()
    suspend fun addWallet(wallet: Wallet) = walletDao.insert(wallet)

    // Spese
    val expenses: Flow<List<Expense>> = expenseDao.getAll()
    suspend fun addExpense(expense: Expense) {
        expenseDao.insert(expense)
        updateCategoryBalance(expense.passiveCategoryId)  // 🔥 Anche qui deve essere aggiornata


        val wallet = walletDao.getById(expense.walletId)
        if (wallet != null && expense.timestamp >= wallet.startTimestamp && !expense.planned) {
            val newBalance = wallet.currentBalance - expense.amount
            val updatedWallet = wallet.copy(currentBalance = newBalance)
            walletDao.update(updatedWallet)
        }
    }

    // Calcoli per residui
    fun getTotalSpentFromWallet(walletId: Int): Flow<Double?> =
        expenseDao.getTotalSpentFromWallet(walletId)

    fun getTotalSpentForCategory(categoryId: Int): Flow<Double?> =
        expenseDao.getTotalSpentForCategory(categoryId)

    suspend fun deleteWallet(wallet: Wallet) {
        walletDao.delete(wallet)
    }

    suspend fun updateWallet(wallet: Wallet) {
        walletDao.update(wallet)
    }

    suspend fun deleteExpense(expense: Expense) {
        expenseDao.delete(expense)
        updateWalletBalance(expense.walletId)
        updateCategoryBalance(expense.passiveCategoryId)  // 🔥 E anche qui
    }

    suspend fun updateExpense(expense: Expense) {
        expenseDao.update(expense)
        updateWalletBalance(expense.walletId)
        updateCategoryBalance(expense.passiveCategoryId)  // 🔥 Anche qui deve essere aggiornata
    }

    suspend fun calculateCurrentBalanceForWallet(walletId: Int): Double {
        val wallet = walletDao.getById(walletId) ?: return 0.0
        val expenses = expenseDao.getExpensesForWalletSince(walletId, wallet.startTimestamp)
        val totalSpent = expenses.sumOf { it.amount }
        return wallet.initialBalance - totalSpent
    }

    suspend fun updateWalletBalance(walletId: Int) {
        val newBalance = calculateCurrentBalanceForWallet(walletId)
        walletDao.updateBalance(walletId, newBalance)
    }

    suspend fun deleteCategory(category: Category) {
        categoryDao.delete(category)
    }

    // 🔥 Funzione che calcola il currentBalance
    private suspend fun updateCategoryBalance(categoryId: Int) {
        val category = categoryDao.getById(categoryId)
        if (category != null) {
            val totalExpenses = expenseDao.getTotalAmountByCategory(categoryId, category.budgetStartDate)
            val updatedBalance = category.initialBudget - totalExpenses
            val updatedCategory = category.copy(currentBalance = updatedBalance)
            categoryDao.update(updatedCategory)
        }
    }


    suspend fun updateCategory(category: Category) {
        categoryDao.update(category)
        updateCategoryBalance(category.id)
    }

}

